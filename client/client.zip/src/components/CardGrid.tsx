import React, { useState, useEffect } from 'react';
import Card from './Card';
import axios from 'axios';
import { NavLink } from 'react-router-dom';
import '../assets/stylesheets/CardGrid.css';

type CardGridProps = {};

type MovieProps = {
  // title: string;
  // genres: string[];
  // released: string;
  // poster: string;

  id: string;
  image: string;
  title: string;
  genres: string;
};

const CardGrid = (props: CardGridProps) => {
  const [movies, setMovies] = useState<MovieProps[]>([]);

  useEffect(() => {
    const getMovies = async () => {
      try {
        const response = await axios.get('http://localhost:4000/get-movie');
        setMovies(response.data);
      } catch (err) {
        console.log(err);
      }
    };
    getMovies();
  }, []);

  return (
    <div className='container-fluid card-grid'>
      <div className='rows cards'>
        <div className='col card-items'>
          <div className='card-grid-container'>
            {movies.map((movie) => (
              <NavLink to={`/movie/${movie.id}`} className='movie-links'>
                <div className='card-grid-item'>
                  <Card
                    // title={movie.title}
                    // genres={movie.genres}
                    // releasedDate={movie.released}
                    // imgUrl={movie.poster}
                    id={movie.id}
                    title={movie.title}
                    genres={movie.genres}
                    imgUrl={movie.image}
                    key={movie.id}
                  />
                </div>
              </NavLink>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CardGrid;
