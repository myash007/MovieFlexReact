import React from 'react';

const SearchMovies = () => {
  return <div></div>;
};

export default SearchMovies;
