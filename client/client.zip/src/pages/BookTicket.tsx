import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import clsx from 'clsx';
import { Form, Button, Dropdown, ButtonGroup } from 'react-bootstrap';
import '../assets/stylesheets/Movie.css';
import '../assets/stylesheets/Login.css';
import star from '../assets/images/star.png';

type MovieDataProps = {
  id: string;
  image: string;
  title: string;
  description: string;
  genres: string;

};
const movies = [
  {
    name: 'Avenger',
  },
  {
    name: 'Joker',
  },
  {
    name: 'Toy story',
  },
  {
    name: 'the lion king',
  },
]
const timing = [
  {
    showTime: '3:00 pm',
  },
  {
    showTime: '6:00 pm',
  },
  {
    showTime: '9:00 pm',
  },
  {
    showTime: '10:45 pm',
  },
]
const seats = Array.from({ length: 8 * 8 }, (_, i) => i);
const BookTicket = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [movieData, setMovieData] = useState<MovieDataProps>();
  const [selectedSeats, setSelectedSeats] = useState([]);
  const disablePastDate = () => {
    const today = new Date();
    const dd = String(today.getDate() + 1).padStart(2, "0");
    const mm = String(today.getMonth() + 1).padStart(2, "0");
    const yyyy = today.getFullYear();
    return yyyy + "-" + mm + "-" + dd;
  };
  const disableAfterTwoDate = () => {
    const today = new Date().toISOString().split('T')[0];
    var twoWeek = new Date(new Date().getTime() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    return twoWeek;
  };
  const [movieBookingForm, setMovieBookingForm] = useState({
    location: '',
    selectedDate: '',
    selectedTime: ''
  });

  


  const handleMovieBookingFormSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    // console.log({ registerForm });

    //by default it will submit the form, so prevent it using preventDefault method
    e.preventDefault();
    const bookMovie = { ...movieBookingForm };
    setMovieBookingForm({
      location: '',
      selectedDate: '',
      selectedTime: ''
    });
  };
  const updateMovieBookingForm = (value: object) => {
    return setMovieBookingForm((prev) => {
      return { ...prev, ...value };
    });
  };


  useEffect(() => {
    const getMovieById = async () => {
      try {
        const url = `http://localhost:4000/movie/${id}`;
        console.log(url);
        const response = await axios.get(url);
        setMovieData(response.data);
      } catch (err) {
        console.log(err);
      }
    };
    getMovieById();
  }, [id]);

  const movieImg = movieData?.image;
  return (
    <div className='container-fluid movie'>
      <div className='row movie-poster-row'>
        <div className='col'>
          <div className='movie-det-section'>
            <img
              src={movieImg}
              alt='Movie not found'
              className='movie-poster'
            />
           
          </div>
          
        </div>
        
      </div>

      <div className='row movie-det-row'>
        <div className='col-lg-5 movie-col'>
          <img src={movieImg} alt='Movie not found' className='movie-img' />
        </div>
        <div className='col-lg-7 movie-det-col'>
          <div className='col-lg-10 movie-form login-form'>
            <h2 style={{ color: 'black' }}>Book Ticket</h2>
            <hr />
            <Form onSubmit={handleMovieBookingFormSubmit}>
              <Form.Group className='mb-3' controlId='location'>
                <Form.Label style={{ color: 'black' }}>Choose Theater</Form.Label>
                <br />
                <select name="country" className="form-control" onChange={(e) => updateMovieBookingForm({ location: e.target.value })}>
                  <option>--Select Location--</option>
                  {
                    movies.map(movie => (
                      <option key={movie.name} value={movie.name}> {movie.name}</option>
                    ))
                  }
                </select>
                <Form.Text className='text-muted'>
                  Select your nearest location to save your time.
                </Form.Text>
              </Form.Group>

              <Form.Group className='mb-3' controlId='date'>
                <Form.Label style={{ color: 'black' }}>Select Date</Form.Label>
                <Form.Control
                  required
                  type='date'
                  min={disablePastDate()}
                  max={disableAfterTwoDate()}
                  placeholder='Choose Date'
                  value={movieBookingForm.selectedDate}
                  onChange={(e) => updateMovieBookingForm({ selectedDate: e.target.value })}
                />

              </Form.Group>
              <Form.Group className='mb-3' controlId='date'>
                <Form.Label style={{ color: 'black' }}>Select Time</Form.Label>


                <ul className='show-time' onClick={(e) => updateMovieBookingForm({ selectedTime: e.target.value })}>
                  {timing.map((showTime) => (
                    <li>{showTime.showTime}</li>
                  ))}
                </ul>
              </Form.Group>

              

              <Button variant='primary' type='submit'>
                Book Ticket
              </Button>
            </Form>
          </div>

          {/* <div className='movie-title'>{movieData?.title}</div>
          <div className='general-info'>

            <span className='movie-genres'>{movieData?.genres}</span>
          </div> */}

          {/* <div className='book-ticket-btn'>
            <Button variant='primary' type='submit' className='book-tkt-btn' onClick={()=>navigate("/book-ticket")}>
              Book Tickets
            </Button>
          </div> */}
        </div>
      </div>
    </div>
  );
};

// function Cinema({ movie, selectedSeats, onSelectedSeatsChange }: any) {
//   function handleSelectedState(seat: any) {
//     const isSelected = selectedSeats.includes(seat);
//     if (isSelected) {
//       onSelectedSeatsChange(
//         selectedSeats.filter((selectedSeat: any) => selectedSeat !== seat)
//       );
//     } else {
//       onSelectedSeatsChange([...selectedSeats, seat]);
//     }
//   }

//   return (
//     <div className='Cinema'>
//       <div className='screen' />

//       <div className='seats'>
//         {seats.map((seat) => {
//           const isSelected = selectedSeats.includes(seat);
//           const isOccupied = movie.occupied.includes(seat);
//           return (
//             <span
//               // tabIndex=0
//               key={seat}
//               className={clsx(
//                 'seat',
//                 isSelected && 'selected',
//                 isOccupied && 'occupied'
//               )}
//               onClick={isOccupied ? undefined : () => handleSelectedState(seat)}
//               // onKeyPress={
//               //   isOccupied
//               //     ? null
//               //     : (e) => {
//               //         if (e.key === 'Enter') {
//               //           handleSelectedState(seat);
//               //         }
//               //       }
//               // }
//             />
//           );
//         })}
//       </div>
//     </div>
//   );
// }
// function ShowCase() {
//   return (
//     <ul className='ShowCase'>
//       <li>
//         <span className='seat' /> <small>N/A</small>
//       </li>
//       <li>
//         <span className='seat selected' /> <small>Selected</small>
//       </li>
//       <li>
//         <span className='seat occupied' /> <small>Occupied</small>
//       </li>
//     </ul>
//   );
// }

export default BookTicket;
