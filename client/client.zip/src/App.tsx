import React, { useState } from 'react';
import './App.css';
import { Routes, Route } from 'react-router-dom';
import Navigation from './pages/Navigation';
import Footer from './pages/Footer';
import Home from './pages/Home';
import Movie from './pages/Movie';
import BookTicket from './pages/BookTicket';
import SearchMovies from './pages/SearchMovies';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './pages/Profile';
// import AdminIndex from './pages/admin/AdminIndex'

import AuthContext from './context/AuthContext';

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const login = () => {
    setIsLoggedIn(true);
  };
  const logout = () => {
    setIsLoggedIn(false);
  };
  return (
    <AuthContext.Provider
      value={{ isLoggedIn: isLoggedIn, login: login, logout: logout }}
    >
      <div className='main-app'>
        <Navigation />
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='movie/:id' element={<Movie />} />
          <Route path='book-ticket/:id' element={<BookTicket />} />
          <Route path='search-movie' element={<SearchMovies />} />
          <Route path='login' element={<Login />} />
          {/* <Route path='logout' element={<Home />} /> */}
          <Route path='register' element={<Register />} />
          <Route path='profile' element={<Profile />} />
          {/* <Route path='admin' element={<AdminIndex />} /> */}
        </Routes>
        <Footer />
      </div>
    </AuthContext.Provider>
  );
};

export default App;
